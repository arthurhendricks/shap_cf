This project uses code from Recourse project:

BSD 3-Clause License

Copyright (c) 2018, Berk Ustun
All rights reserved.

The experiments with crime are not available because of data availability.

To install this library you should be in the same folder as this file and do:

pip install .

Further detais about documentation can be viewed in documentation folder.
